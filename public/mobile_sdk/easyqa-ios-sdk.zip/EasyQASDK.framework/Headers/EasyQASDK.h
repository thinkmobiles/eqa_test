//
//  EasyQASDK.h
//  EasyQASDK
//
//  Created by Ivan Grab on 06.02.17.
//  Copyright © 2017 Ivan Grab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <EasyQASDK/EasyQAIntegration.h>

//! Project version number for EasyQASDK.
FOUNDATION_EXPORT double EasyQASDKVersionNumber;

//! Project version string for EasyQASDK.
FOUNDATION_EXPORT const unsigned char EasyQASDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EasyQASDK/PublicHeader.h>
