//

#import <Foundation/Foundation.h>

@interface EasyQAIntegration : NSObject

@property (strong, nonatomic, readonly) NSURL *baseURL;
@property (strong, nonatomic, readonly) NSString *writeKey;


+ (instancetype)sharedAnalytics;
+ (void)setUpWithBaseURL:(NSURL *)baseURL andWriteKey:(NSString *)writeKey;

- (void)changeAPIBaseURL:(NSURL *)apiBaseURL;
- (void)changeAPISecret:(NSString *)apiSecret;

@end
